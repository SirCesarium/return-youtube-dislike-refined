Return Youtube Dislike Refined

# Build Instructions

1. Install Node.js and npm.
2. Run `npm install` to install dependencies.
3. Run `npm run build` to generate the extension files.

The output will be in the `Extensions/combined/dist/firefox` folder.